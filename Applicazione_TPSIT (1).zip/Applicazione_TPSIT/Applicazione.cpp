#include <iostream>
#include <fstream>
#include "unistd.h"
#include "sys/wait.h"
#include "string"
#include "bits/stdc++.h"
#include<dirent.h>
#include <cctype>

using namespace std;

int main(){
    int numAzione = 0;
    while(numAzione!=9){
        fstream FileOpzioni;
    FileOpzioni.open("./OPZIONI.txt", ios::in);
    cout << "_______________________" << endl;
    cout << "\nOPZIONI:\n" << endl;
    string opzione;
    numAzione = 0;
    while(getline(FileOpzioni, opzione)){
        cout << numAzione << " - " << opzione << endl;
        numAzione++;
    }
    cout << "\n_______________________" << endl;
    cout << "\nAzione: ";
    cin >> numAzione;
    
    string general;
    string estensione;

   char lettera;
   fstream file;
   fstream file2;
   string appoggio;
   string copy;
   int i = 0, j = 0;
   system("rm ./salvataggio.txt percorso.txt");
    switch(numAzione){
        case 0:
        /*if((direcory = opendir(curr)) != NULL){
            while ((x = readdir(direcory)) != NULL)
            {
                if(file_cartella == x -> d_name){
                    check = true;
                    cout << x -> d_name;
                }
            }
            
        }*/
        cout << "Inserire il nome da file da ricercare:" << endl;
        cin >> general;
        cout << "Inserire l'estensione del file (premere 0 e invio se non ha esensioni): " << endl;
        cin >> estensione;
        if(estensione == "0"){
            estensione = "";
        }
        else{
            estensione = "." + estensione;
        }
        general = "find . -type f -name '" + general + estensione + "' > salvataggio.txt";
        system(general.c_str());
        system("cat salvataggio.txt");
        break;

        case 1:
        //grep -Ril "text-to-find-here" /
        cout << "Inserire la parola da ricercare: " << endl;
        cin >> general;
        general = "grep -Ril '" + general + "' .";
        system(general.c_str());
        break;

        case 2:
        cout << "Inserire l'estensione di cui si vuole trovare i file: " << endl;
        cin >> estensione;
        if(estensione == "0"){
            estensione = "";
        }
        else{
            estensione = "." + estensione;
        }
        estensione = "find . -type f -name '**" + estensione + "' >> salvataggio.txt ";
        system(estensione.c_str());
        1system("cat salvataggio.txt");
        break;

        case 3:
        system("find . -type f -execdir basename '{}' ';' >> salvataggio.txt");
        file.open("salvataggio.txt");
        while(getline(file, general)){
            if(general != "salvataggio.txt" && general != "percorso.txt" && general != "Opzioni.txt" && general != "Applicazione.cpp" && general != "ciao" && general != "OPZIONI.txt"){
            system("rm ./percorso.txt");
            copy = "find . -type f -name '" + general + "' >> percorso.txt";
            system(copy.c_str());
            lettera = toupper(general[0]);
            appoggio = "mkdir ";
            appoggio += lettera;
            system(appoggio.c_str());
            file2.open("percorso.txt");
            while(getline(file2, estensione)){
            general = "mv " + estensione + " ./" + lettera;
            system(general.c_str());
            }
            file2.close();
            }
        }
        file.close();
        /*while(getline(file2, estensione)){
            general = "mv " + estensione  + " ./" + lettera;
            system(general.c_str());
        }*/
        system("find . -type d -empty -delete");
        system("clear");
        cout << "I FILE SONO STATI SPOSTATI NELLE CARTELLE CON I FILE CHE INIZIANO CON LA STESSA LETTERA" << endl;
        break;

        case 4:
        system("find . -type f -execdir basename '{}' ';' >> salvataggio.txt");
        file.open("salvataggio.txt");
        while(getline(file, general)){
            string general1;
            if(general != "salvataggio.txt" && general != "percorso.txt" && general != "Opzioni.txt" && general != "Applicazione.cpp" && general != "ciao" && general != "OPZIONI.txt"){
            system("rm ./percorso.txt");
            general1 = "find . -type f -name '" + general + "' >> percorso.txt";
            system(general1.c_str());

            for(i = 0; i<general.length(); i++){
                if(general[i]=='.'){
                    j = i;
                } 
            }

            appoggio = "";
            for(j = j+1; j<general.length(); j++){
                appoggio += general[j];
            }
            file2.open("percorso.txt");
            while(getline(file2, estensione)){
                general1 = "mkdir " + appoggio;
                system(general1.c_str());
                general1 = "mv " + estensione + " ./" + appoggio;
                system(general1.c_str());
            }
            file2.close();
            }
            
        }
        file.close();
        system("find . -type d -empty -delete");
        i = 0;
        system("clear");
        cout << "I FILE SONO STATI SPOSTATI NELLE CARTELLE CON I FILE CHE HANNO LA MEDESIMA ESTENSIONE" << endl;
        break;
        case 5:
        break;
        case 6:
        break;
        case 7:
        break;
        case 8:
        break;
    }
    }
    system("clear");
    cout << "PROGRAMMA TERMINATO" << endl;
    return 0;
}